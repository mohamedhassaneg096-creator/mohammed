"""AutoCut application package."""
